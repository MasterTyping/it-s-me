# @mt/three-urdf-loader

URDF loader for three.js and @react-three/fiber with WebAssembly optimization

## Installation

```bash
npm install @mt/three-urdf-loader three @react-three/fiber
```

## Next.js Usage

### 1. Basic URDF Loading with `URDFModel` Component

```tsx
'use client'
import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { URDFModel } from '@mt/three-urdf-loader'

export default function RobotViewer() {
  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <Canvas camera={{ position: [2, 2, 2] }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <URDFModel
          url="/robots/my-robot.urdf"
          onLoad={(model) => console.log('Loaded:', model)}
        />
        <OrbitControls />
      </Canvas>
    </div>
  )
}
```

### 2. `URDFModel` with Joint Control

```tsx
'use client'
import { useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { URDFModel } from '@mt/three-urdf-loader'

export default function ControllableRobot() {
  const [jointValues, setJointValues] = useState({ joint1: 0, joint2: 0 })

  return (
    <div>
      <div style={{ width: '100%', height: '70vh' }}>
        <Canvas>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} />
          <URDFModel
            url="/robots/arm.urdf"
            jointValues={jointValues}
            onLoad={(model) => console.log('Robot loaded:', model)}
            onError={(error) => console.error('Load error:', error)}
          />
        </Canvas>
      </div>

      <div style={{ padding: '20px' }}>
        <label>
          Joint 1:
          <input
            type="range"
            min="-3.14"
            max="3.14"
            step="0.01"
            value={jointValues.joint1}
            onChange={(e) =>
              setJointValues((prev) => ({
                ...prev,
                joint1: parseFloat(e.target.value),
              }))
            }
          />
        </label>
      </div>
    </div>
  )
}
```

---

## Hooks API

### `useURDFLoader` — Load and control a URDF model

```tsx
'use client'
import React, { useEffect, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { useURDFLoader } from '@mt/three-urdf-loader'

function RobotScene() {
  const { model, loading, error, loadFromURL, setJointValues } =
    useURDFLoader()
  const [joint1, setJoint1] = useState(0)

  // Load the URDF on mount
  useEffect(() => {
    loadFromURL('/robots/arm.urdf')
  }, [loadFromURL])

  // Reactively update joints whenever the slider changes
  useEffect(() => {
    if (model) {
      setJointValues({ joint1 })
    }
  }, [model, joint1, setJointValues])

  return (
    <>
      {loading && <mesh><boxGeometry /><meshStandardMaterial color="gray" /></mesh>}
      {!loading && !error && model && <primitive object={model} />}

      <div style={{ position: 'absolute', bottom: 20, left: 20 }}>
        <label>
          Joint 1:
          <input
            type="range"
            min="-3.14"
            max="3.14"
            step="0.01"
            value={joint1}
            onChange={(e) => setJoint1(parseFloat(e.target.value))}
          />
        </label>
      </div>
    </>
  )
}

export default function App() {
  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <Canvas camera={{ position: [2, 2, 2] }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} />
        <RobotScene />
        <OrbitControls />
      </Canvas>
    </div>
  )
}
```

**`useURDFLoader` return values**

| Name | Type | Description |
|---|---|---|
| `model` | `ThreeJSURDFModel \| null` | Loaded Three.js model |
| `loading` | `boolean` | `true` while loading |
| `error` | `Error \| null` | Error from the last load attempt |
| `progress` | `number` | Load progress 0–1 |
| `loadFromURL` | `(url, options?) => Promise<ThreeJSURDFModel>` | Load URDF from URL |
| `loadFromString` | `(xml, options?) => Promise<ThreeJSURDFModel>` | Load URDF from XML string |
| `setJointValues` | `(values: Record<string, number>) => void` | Set joint angles (radians) |
| `getJointValues` | `() => Record<string, number>` | Get current joint angles |

---

### `useURDFAnimator` — Timeline-based animation playback

```tsx
'use client'
import React, { useRef, useEffect } from 'react'
import { Canvas } from '@react-three/fiber'
import {
  URDFModel,
  URDFModelRef,
  URDFMotionParser,
  useURDFAnimator,
  InterpolationMode,
  LoopMode,
} from '@mt/three-urdf-loader'

function AnimatedRobot() {
  const modelRef = useRef<URDFModelRef>(null)

  // Load motion frames from a CSV file
  const [frames, setFrames] = React.useState([])
  useEffect(() => {
    const parser = new URDFMotionParser()
    parser.parseFile(window.location.origin, '/robots/motion.csv').then(setFrames)
  }, [])

  const animator = useURDFAnimator(modelRef as any, frames, {
    interpolationMode: InterpolationMode.LINEAR,
    loopMode: LoopMode.LOOP,
    speed: 1.0,
    onFrameChange: (frame, time) => console.log(`t=${time.toFixed(2)}s`),
    onCompletion: () => console.log('Animation finished'),
  })

  return (  
    <>
      <URDFModel ref={modelRef} url="/robots/arm.urdf" />

      <div style={{ position: 'absolute', bottom: 20, left: 20 }}>
        <button onClick={animator.play}>▶ Play</button>
        <button onClick={animator.pause}>⏸ Pause</button>
        <button onClick={animator.stop}>⏹ Stop</button>
        <input
          type="range"
          min={0}
          max={animator.duration}
          step={0.01}
          value={animator.currentTime}
          onChange={(e) => animator.seek(parseFloat(e.target.value))}
        />
        <span>{animator.currentTime.toFixed(2)}s / {animator.duration.toFixed(2)}s</span>
      </div>
    </>
  )
}

export default function App() {
  return (
    <Canvas camera={{ position: [2, 2, 2] }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} />
      <AnimatedRobot />
    </Canvas>
  )
}
```

**`useURDFAnimator` return values**

| Name | Type | Description |
|---|---|---|
| `playbackState` | `PlaybackState` | `STOPPED` / `PLAYING` / `PAUSED` |
| `currentTime` | `number` | Current time in seconds |
| `duration` | `number` | Total animation duration |
| `progress` | `number` | Progress 0–1 |
| `speed` | `number` | Current playback speed |
| `loading` | `boolean` | `true` while initialising |
| `error` | `Error \| null` | Initialisation error |
| `play()` | `() => void` | Start playback |
| `pause()` | `() => void` | Pause playback |
| `stop()` | `() => void` | Stop and reset |
| `seek(time)` | `(number) => void` | Jump to time |
| `setSpeed(s)` | `(number) => void` | Change playback speed |
| `setInterpolationMode(m)` | `(InterpolationMode) => void` | Change interpolation |
| `setLoopMode(m)` | `(LoopMode) => void` | Change loop behaviour |
| `getJointValues()` | `() => Record<string, number>` | Interpolated joint values at current time |
| `getBaseTransform()` | `() => { position, rotation } \| null` | Base transform at current time |

---

### `useCannonPhysics` — Cannon.js physics world

```tsx
'use client'
import React, { useEffect } from 'react'
import * as CANNON from 'cannon-es'
import { Canvas } from '@react-three/fiber'
import { useCannonPhysics } from '@mt/three-urdf-loader'

function PhysicsScene() {
  const physics = useCannonPhysics({ gravity: [0, -9.81, 0], timeStep: 1 / 60 })

  useEffect(() => {
    // Add a static ground plane
    const ground = new CANNON.Body({ mass: 0, shape: new CANNON.Plane() })
    ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0)
    physics.addBody(ground)

    // Add a dynamic sphere
    const sphere = new CANNON.Body({ mass: 1, shape: new CANNON.Sphere(0.5) })
    sphere.position.set(0, 5, 0)
    physics.addBody(sphere)

    return () => {
      physics.removeBody(sphere)
      physics.removeBody(ground)
    }
  }, [physics])

  return null
}

export default function App() {
  return (
    <Canvas>
      <ambientLight />
      <PhysicsScene />
    </Canvas>
  )
}
```

**`useCannonPhysics` return values**

| Name | Type | Description |
|---|---|---|
| `world` | `CANNON.World` | Raw Cannon world instance |
| `physicsWorld` | `PhysicsWorld` | Managed wrapper |
| `addBody(body)` | `(CANNON.Body) => void` | Add a body |
| `removeBody(body)` | `(CANNON.Body) => void` | Remove a body |
| `addConstraint(c)` | `(CANNON.Constraint) => void` | Add a constraint |
| `removeConstraint(c)` | `(CANNON.Constraint) => void` | Remove a constraint |
| `setGravity(g)` | `([x,y,z]) => void` | Set gravity vector |
| `step()` | `() => void` | Manually step the simulation |
| `clear()` | `() => void` | Remove all bodies and constraints |
| `getBodies()` | `() => CANNON.Body[]` | List all bodies |

---

### `useCollisionDetection` — Collision monitoring

```tsx
'use client'
import React, { useEffect } from 'react'
import { Canvas } from '@react-three/fiber'
import { useCannonPhysics, useCollisionDetection } from '@mt/three-urdf-loader'

function CollisionScene() {
  const physics = useCannonPhysics({ gravity: [0, -9.81, 0] })
  const collision = useCollisionDetection(physics.world)

  useEffect(() => {
    // Track named robot links for self-collision detection
    collision.registerRobotBodies(['link1', 'link2', 'link3'])
    collision.setSelfCollisionEnabled(true)
    collision.setEnvironmentCollisionEnabled(true)

    // Register a one-off callback for custom handling
    const unsubscribe = collision.registerContactCallback((event) => {
      console.log('Collision between', event.bodyA, 'and', event.bodyB)
    })

    return unsubscribe
  }, [collision])

  // collision.collisions is updated every frame (~60 fps)
  return (
    <mesh>
      <boxGeometry />
      <meshStandardMaterial color={collision.collisions.length > 0 ? 'red' : 'green'} />
    </mesh>
  )
}

export default function App() {
  return (
    <Canvas>
      <ambientLight />
      <CollisionScene />
    </Canvas>
  )
}
```

**`useCollisionDetection` return values**

| Name | Type | Description |
|---|---|---|
| `collisions` | `CollisionEvent[]` | Active collisions this frame |
| `registerContactCallback(cb)` | `(OnCollisionCallback) => () => void` | Subscribe to collision events; returns unsubscribe function |
| `setSelfCollisionEnabled(b)` | `(boolean) => void` | Toggle self-collision detection |
| `setEnvironmentCollisionEnabled(b)` | `(boolean) => void` | Toggle environment collision detection |
| `registerRobotBodies(names)` | `(string[]) => void` | Register link names to track |
| `clearCollisions()` | `() => void` | Clear current collision list |

---

## API Reference

### `URDFModel` Props

| Prop | Type | Description |
|---|---|---|
| `url` | `string` | URL of the URDF file |
| `xmlString` | `string` | Raw URDF XML string (alternative to `url`) |
| `jointValues` | `Record<string, number>` | Joint angles in radians |
| `position` | `[x, y, z]` | Three.js position |
| `rotation` | `[x, y, z]` | Three.js rotation (Euler, radians) |
| `scale` | `[x, y, z]` | Three.js scale |
| `onLoad` | `(model: ThreeJSURDFModel) => void` | Called when loaded |
| `onProgress` | `(progress: number) => void` | Called with load progress 0–1 |
| `onError` | `(error: Error) => void` | Called on error |

`URDFModel` also accepts a `ref` (`URDFModelRef`) exposing imperative methods:
`setJointValues`, `getJointValues`, `getLinkByName`, `getJointByName`, `setTransform`, `forceUpdateTransform`.

## Performance Tips for Next.js

1. **Preload URDF files**: Place URDF files in the `public/` folder
2. **Use dynamic imports**: For better code splitting with Next.js
3. **Optimize meshes**: Use compressed mesh formats when possible
4. **Client-side only**: Always add the `'use client'` directive

## Coordinate System Handling

This loader automatically handles coordinate system differences between various mesh formats:

- **STL**: No transformation needed (works correctly as-is)
- **GLB/GLTF**: Automatically converts from Y-up to Z-up coordinate system
- **DAE (Collada)**: Automatically converts from Y-up to Z-up coordinate system
- **OBJ**: Optional transformation (can be enabled if needed)

URDF uses Z-up, while GLB/DAE use Y-up. The loader applies a 90° X-axis rotation automatically.

### Manual Coordinate System Control

```typescript
import { MeshUtils } from '@mt/three-urdf-loader/utils'

// Apply custom transformation to a geometry
MeshUtils.applyCoordinateTransform(geometry, 'glb')

// Or apply custom scale
MeshUtils.normalizeMeshScale(geometry, { x: 2, y: 2, z: 2 })
```

## Examples

See the `/examples/react-three-fiber` folder for full working examples including animation and physics.

## License

MIT