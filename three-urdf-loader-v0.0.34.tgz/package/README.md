# @mt/three-urdf-loader

URDF loader for three.js and @react-three/fiber with WebAssembly optimization

## Installation

```bash
npm install @mt/three-urdf-loader three @react-three/fiber
```

## Next.js Usage

### 1. Basic URDF Loading in Next.js

```tsx
'use client'
import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { URDFRobot } from '@mt/three-urdf-loader'

export default function RobotViewer() {
  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <Canvas camera={{ position: [2, 2, 2] }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <URDFRobot 
          urdfPath="/robots/my-robot.urdf" 
          meshPath="/robots/meshes/"
        />
        <OrbitControls />
      </Canvas>
    </div>
  )
}
```

### 2. With Joint Control

```tsx
'use client'
import { useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { URDFRobot } from '@mt/three-urdf-loader'

export default function ControllableRobot() {
  const [jointAngles, setJointAngles] = useState({ joint1: 0, joint2: 0 })

  return (
    <div>
      <div style={{ width: '100%', height: '70vh' }}>
        <Canvas>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} />
          <URDFRobot 
            urdfPath="/robots/arm.urdf"
            jointAngles={jointAngles}
            onLoad={(robot) => console.log('Robot loaded:', robot)}
          />
        </Canvas>
      </div>
      
      <div style={{ padding: '20px' }}>
        <label>
          Joint 1: 
          <input 
            type="range" 
            min="-180" 
            max="180" 
            value={jointAngles.joint1 * 180 / Math.PI}
            onChange={(e) => setJointAngles(prev => ({
              ...prev, 
              joint1: parseFloat(e.target.value) * Math.PI / 180
            }))
          />
        </label>
      </div>
    </div>
  )
}
```

### 3. Loading with Suspense

```tsx
'use client'
import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { URDFRobot } from '@mt/three-urdf-loader'

function LoadingFallback() {
  return (
    <mesh>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="orange" />
    </mesh>
  )
}

export default function SuspenseRobot() {
  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <Canvas>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <Suspense fallback={<LoadingFallback />}>
          <URDFRobot urdfPath="/robots/complex-robot.urdf" />
        </Suspense>
      </Canvas>
    </div>
  )
}
```

## API Reference

### URDFRobot Props

- `urdfPath: string` - Path to URDF file
- `meshPath?: string` - Base path for mesh files
- `jointAngles?: Record<string, number>` - Joint angles in radians
- `onLoad?: (robot: URDFRobotType) => void` - Callback when robot is loaded
- `onError?: (error: Error) => void` - Error callback

## Performance Tips for Next.js

1. **Preload URDF files**: Place URDF files in `public/` folder
2. **Use dynamic imports**: For better code splitting
3. **Optimize meshes**: Use compressed mesh formats when possible
4. **Client-side only**: Always use `'use client'` directive

## Coordinate System Handling

This loader automatically handles coordinate system differences between various mesh formats:

### Supported Formats & Transformations

- **STL**: No transformation needed (works correctly as-is)
- **GLB/GLTF**: Automatically converts from Y-up to Z-up coordinate system
- **DAE (Collada)**: Automatically converts from Y-up to Z-up coordinate system
- **OBJ**: Optional transformation (can be enabled if needed)

### Coordinate System Details

URDF typically uses a Z-up coordinate system, while many modern 3D formats (GLB, DAE) use Y-up. This loader automatically applies the necessary transformations:

```typescript
// For GLB/GLTF files, the loader automatically applies:
// - 90-degree rotation around X-axis to convert Y-up to Z-up
// - Maintains proper scaling and positioning
```

### Manual Coordinate System Control

If you need custom coordinate transformations:

```typescript
import { MeshUtils } from '@mt/three-urdf-loader/utils'

// Apply custom transformation to a geometry
MeshUtils.applyCoordinateTransform(geometry, 'glb')

// Or apply custom scale
MeshUtils.normalizeMeshScale(geometry, { x: 2, y: 2, z: 2 })
```

## Examples

See the `/examples` folder for complete Next.js integration examples.

## License

MIT