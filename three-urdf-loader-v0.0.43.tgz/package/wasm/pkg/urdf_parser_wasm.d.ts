/* tslint:disable */
/* eslint-disable */

export class JointData {
    free(): void;
    [Symbol.dispose](): void;
    constructor(name: string, joint_type: string, parent_link: string, child_link: string, transform: Transform, axis: Vector3, lower_limit: number, upper_limit: number);
    axis: Vector3;
    lower_limit: number;
    transform: Transform;
    upper_limit: number;
    readonly child_link: string;
    readonly joint_type: string;
    readonly name: string;
    readonly parent_link: string;
}

export class LinkData {
    free(): void;
    [Symbol.dispose](): void;
    constructor(name: string, visual_mesh_url: string | null | undefined, collision_mesh_url: string | null | undefined, transform: Transform, color: Vector3);
    color: Vector3;
    transform: Transform;
    readonly collision_mesh_url: string | undefined;
    readonly name: string;
    readonly visual_mesh_url: string | undefined;
}

export class Quaternion {
    free(): void;
    [Symbol.dispose](): void;
    static identity(): Quaternion;
    constructor(x: number, y: number, z: number, w: number);
    w: number;
    x: number;
    y: number;
    z: number;
}

export class Transform {
    free(): void;
    [Symbol.dispose](): void;
    static identity(): Transform;
    constructor(position: Vector3, rotation: Quaternion);
    position: Vector3;
    rotation: Quaternion;
}

export class URDFModel {
    free(): void;
    [Symbol.dispose](): void;
    get_joint(index: number): JointData | undefined;
    get_joints_count(): number;
    get_link(index: number): LinkData | undefined;
    get_links_count(): number;
    constructor(name: string);
    readonly name: string;
}

export class Vector3 {
    free(): void;
    [Symbol.dispose](): void;
    constructor(x: number, y: number, z: number);
    x: number;
    y: number;
    z: number;
}

export function compute_forward_kinematics(model: URDFModel, joint_values: Float64Array): Transform[];

export function parse_urdf_xml(xml_content: string): URDFModel;

export function test_parsing(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_get_jointdata_axis: (a: number) => number;
    readonly __wbg_get_jointdata_lower_limit: (a: number) => number;
    readonly __wbg_get_jointdata_transform: (a: number) => number;
    readonly __wbg_get_jointdata_upper_limit: (a: number) => number;
    readonly __wbg_get_quaternion_w: (a: number) => number;
    readonly __wbg_get_quaternion_x: (a: number) => number;
    readonly __wbg_get_quaternion_y: (a: number) => number;
    readonly __wbg_get_quaternion_z: (a: number) => number;
    readonly __wbg_get_transform_position: (a: number) => number;
    readonly __wbg_get_transform_rotation: (a: number) => number;
    readonly __wbg_jointdata_free: (a: number, b: number) => void;
    readonly __wbg_linkdata_free: (a: number, b: number) => void;
    readonly __wbg_quaternion_free: (a: number, b: number) => void;
    readonly __wbg_set_jointdata_axis: (a: number, b: number) => void;
    readonly __wbg_set_jointdata_lower_limit: (a: number, b: number) => void;
    readonly __wbg_set_jointdata_transform: (a: number, b: number) => void;
    readonly __wbg_set_jointdata_upper_limit: (a: number, b: number) => void;
    readonly __wbg_set_quaternion_w: (a: number, b: number) => void;
    readonly __wbg_set_quaternion_x: (a: number, b: number) => void;
    readonly __wbg_set_quaternion_y: (a: number, b: number) => void;
    readonly __wbg_set_quaternion_z: (a: number, b: number) => void;
    readonly __wbg_set_transform_position: (a: number, b: number) => void;
    readonly __wbg_set_transform_rotation: (a: number, b: number) => void;
    readonly __wbg_transform_free: (a: number, b: number) => void;
    readonly __wbg_urdfmodel_free: (a: number, b: number) => void;
    readonly __wbg_vector3_free: (a: number, b: number) => void;
    readonly compute_forward_kinematics: (a: number, b: number, c: number) => [number, number];
    readonly jointdata_child_link: (a: number) => [number, number];
    readonly jointdata_joint_type: (a: number) => [number, number];
    readonly jointdata_name: (a: number) => [number, number];
    readonly jointdata_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => number;
    readonly jointdata_parent_link: (a: number) => [number, number];
    readonly linkdata_collision_mesh_url: (a: number) => [number, number];
    readonly linkdata_name: (a: number) => [number, number];
    readonly linkdata_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly linkdata_visual_mesh_url: (a: number) => [number, number];
    readonly parse_urdf_xml: (a: number, b: number) => [number, number, number];
    readonly quaternion_identity: () => number;
    readonly quaternion_new: (a: number, b: number, c: number, d: number) => number;
    readonly test_parsing: () => [number, number];
    readonly transform_identity: () => number;
    readonly transform_new: (a: number, b: number) => number;
    readonly urdfmodel_get_joint: (a: number, b: number) => number;
    readonly urdfmodel_get_joints_count: (a: number) => number;
    readonly urdfmodel_get_link: (a: number, b: number) => number;
    readonly urdfmodel_get_links_count: (a: number) => number;
    readonly urdfmodel_name: (a: number) => [number, number];
    readonly urdfmodel_new: (a: number, b: number) => number;
    readonly vector3_new: (a: number, b: number, c: number) => number;
    readonly __wbg_set_linkdata_color: (a: number, b: number) => void;
    readonly __wbg_set_linkdata_transform: (a: number, b: number) => void;
    readonly __wbg_set_vector3_x: (a: number, b: number) => void;
    readonly __wbg_set_vector3_y: (a: number, b: number) => void;
    readonly __wbg_set_vector3_z: (a: number, b: number) => void;
    readonly __wbg_get_linkdata_color: (a: number) => number;
    readonly __wbg_get_linkdata_transform: (a: number) => number;
    readonly __wbg_get_vector3_x: (a: number) => number;
    readonly __wbg_get_vector3_y: (a: number) => number;
    readonly __wbg_get_vector3_z: (a: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
