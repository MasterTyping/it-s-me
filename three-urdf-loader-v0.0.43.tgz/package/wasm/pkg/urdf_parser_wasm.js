/* @ts-self-types="./urdf_parser_wasm.d.ts" */

export class JointData {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(JointData.prototype);
        obj.__wbg_ptr = ptr;
        JointDataFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        JointDataFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jointdata_free(ptr, 0);
    }
    /**
     * @returns {Vector3}
     */
    get axis() {
        const ret = wasm.__wbg_get_jointdata_axis(this.__wbg_ptr);
        return Vector3.__wrap(ret);
    }
    /**
     * @returns {number}
     */
    get lower_limit() {
        const ret = wasm.__wbg_get_jointdata_lower_limit(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Transform}
     */
    get transform() {
        const ret = wasm.__wbg_get_jointdata_transform(this.__wbg_ptr);
        return Transform.__wrap(ret);
    }
    /**
     * @returns {number}
     */
    get upper_limit() {
        const ret = wasm.__wbg_get_jointdata_upper_limit(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    get child_link() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.jointdata_child_link(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get joint_type() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.jointdata_joint_type(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.jointdata_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} name
     * @param {string} joint_type
     * @param {string} parent_link
     * @param {string} child_link
     * @param {Transform} transform
     * @param {Vector3} axis
     * @param {number} lower_limit
     * @param {number} upper_limit
     */
    constructor(name, joint_type, parent_link, child_link, transform, axis, lower_limit, upper_limit) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(joint_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(parent_link, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(child_link, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        _assertClass(transform, Transform);
        var ptr4 = transform.__destroy_into_raw();
        _assertClass(axis, Vector3);
        var ptr5 = axis.__destroy_into_raw();
        const ret = wasm.jointdata_new(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, ptr5, lower_limit, upper_limit);
        this.__wbg_ptr = ret >>> 0;
        JointDataFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string}
     */
    get parent_link() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.jointdata_parent_link(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {Vector3} arg0
     */
    set axis(arg0) {
        _assertClass(arg0, Vector3);
        var ptr0 = arg0.__destroy_into_raw();
        wasm.__wbg_set_jointdata_axis(this.__wbg_ptr, ptr0);
    }
    /**
     * @param {number} arg0
     */
    set lower_limit(arg0) {
        wasm.__wbg_set_jointdata_lower_limit(this.__wbg_ptr, arg0);
    }
    /**
     * @param {Transform} arg0
     */
    set transform(arg0) {
        _assertClass(arg0, Transform);
        var ptr0 = arg0.__destroy_into_raw();
        wasm.__wbg_set_jointdata_transform(this.__wbg_ptr, ptr0);
    }
    /**
     * @param {number} arg0
     */
    set upper_limit(arg0) {
        wasm.__wbg_set_jointdata_upper_limit(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) JointData.prototype[Symbol.dispose] = JointData.prototype.free;

export class LinkData {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LinkData.prototype);
        obj.__wbg_ptr = ptr;
        LinkDataFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LinkDataFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_linkdata_free(ptr, 0);
    }
    /**
     * @returns {Vector3}
     */
    get color() {
        const ret = wasm.__wbg_get_jointdata_axis(this.__wbg_ptr);
        return Vector3.__wrap(ret);
    }
    /**
     * @returns {Transform}
     */
    get transform() {
        const ret = wasm.__wbg_get_jointdata_transform(this.__wbg_ptr);
        return Transform.__wrap(ret);
    }
    /**
     * @returns {string | undefined}
     */
    get collision_mesh_url() {
        const ret = wasm.linkdata_collision_mesh_url(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.linkdata_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} name
     * @param {string | null | undefined} visual_mesh_url
     * @param {string | null | undefined} collision_mesh_url
     * @param {Transform} transform
     * @param {Vector3} color
     */
    constructor(name, visual_mesh_url, collision_mesh_url, transform, color) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(visual_mesh_url) ? 0 : passStringToWasm0(visual_mesh_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(collision_mesh_url) ? 0 : passStringToWasm0(collision_mesh_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        _assertClass(transform, Transform);
        var ptr3 = transform.__destroy_into_raw();
        _assertClass(color, Vector3);
        var ptr4 = color.__destroy_into_raw();
        const ret = wasm.linkdata_new(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, ptr4);
        this.__wbg_ptr = ret >>> 0;
        LinkDataFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string | undefined}
     */
    get visual_mesh_url() {
        const ret = wasm.linkdata_visual_mesh_url(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @param {Vector3} arg0
     */
    set color(arg0) {
        _assertClass(arg0, Vector3);
        var ptr0 = arg0.__destroy_into_raw();
        wasm.__wbg_set_jointdata_axis(this.__wbg_ptr, ptr0);
    }
    /**
     * @param {Transform} arg0
     */
    set transform(arg0) {
        _assertClass(arg0, Transform);
        var ptr0 = arg0.__destroy_into_raw();
        wasm.__wbg_set_jointdata_transform(this.__wbg_ptr, ptr0);
    }
}
if (Symbol.dispose) LinkData.prototype[Symbol.dispose] = LinkData.prototype.free;

export class Quaternion {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Quaternion.prototype);
        obj.__wbg_ptr = ptr;
        QuaternionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        QuaternionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_quaternion_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get w() {
        const ret = wasm.__wbg_get_quaternion_w(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get x() {
        const ret = wasm.__wbg_get_quaternion_x(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get y() {
        const ret = wasm.__wbg_get_quaternion_y(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get z() {
        const ret = wasm.__wbg_get_quaternion_z(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Quaternion}
     */
    static identity() {
        const ret = wasm.quaternion_identity();
        return Quaternion.__wrap(ret);
    }
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @param {number} w
     */
    constructor(x, y, z, w) {
        const ret = wasm.quaternion_new(x, y, z, w);
        this.__wbg_ptr = ret >>> 0;
        QuaternionFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} arg0
     */
    set w(arg0) {
        wasm.__wbg_set_quaternion_w(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set x(arg0) {
        wasm.__wbg_set_quaternion_x(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set y(arg0) {
        wasm.__wbg_set_quaternion_y(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set z(arg0) {
        wasm.__wbg_set_quaternion_z(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) Quaternion.prototype[Symbol.dispose] = Quaternion.prototype.free;

export class Transform {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Transform.prototype);
        obj.__wbg_ptr = ptr;
        TransformFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TransformFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_transform_free(ptr, 0);
    }
    /**
     * @returns {Vector3}
     */
    get position() {
        const ret = wasm.__wbg_get_transform_position(this.__wbg_ptr);
        return Vector3.__wrap(ret);
    }
    /**
     * @returns {Quaternion}
     */
    get rotation() {
        const ret = wasm.__wbg_get_transform_rotation(this.__wbg_ptr);
        return Quaternion.__wrap(ret);
    }
    /**
     * @param {Vector3} arg0
     */
    set position(arg0) {
        _assertClass(arg0, Vector3);
        var ptr0 = arg0.__destroy_into_raw();
        wasm.__wbg_set_transform_position(this.__wbg_ptr, ptr0);
    }
    /**
     * @param {Quaternion} arg0
     */
    set rotation(arg0) {
        _assertClass(arg0, Quaternion);
        var ptr0 = arg0.__destroy_into_raw();
        wasm.__wbg_set_transform_rotation(this.__wbg_ptr, ptr0);
    }
    /**
     * @returns {Transform}
     */
    static identity() {
        const ret = wasm.transform_identity();
        return Transform.__wrap(ret);
    }
    /**
     * @param {Vector3} position
     * @param {Quaternion} rotation
     */
    constructor(position, rotation) {
        _assertClass(position, Vector3);
        var ptr0 = position.__destroy_into_raw();
        _assertClass(rotation, Quaternion);
        var ptr1 = rotation.__destroy_into_raw();
        const ret = wasm.transform_new(ptr0, ptr1);
        this.__wbg_ptr = ret >>> 0;
        TransformFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) Transform.prototype[Symbol.dispose] = Transform.prototype.free;

export class URDFModel {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(URDFModel.prototype);
        obj.__wbg_ptr = ptr;
        URDFModelFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        URDFModelFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_urdfmodel_free(ptr, 0);
    }
    /**
     * @param {number} index
     * @returns {JointData | undefined}
     */
    get_joint(index) {
        const ret = wasm.urdfmodel_get_joint(this.__wbg_ptr, index);
        return ret === 0 ? undefined : JointData.__wrap(ret);
    }
    /**
     * @returns {number}
     */
    get_joints_count() {
        const ret = wasm.urdfmodel_get_joints_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} index
     * @returns {LinkData | undefined}
     */
    get_link(index) {
        const ret = wasm.urdfmodel_get_link(this.__wbg_ptr, index);
        return ret === 0 ? undefined : LinkData.__wrap(ret);
    }
    /**
     * @returns {number}
     */
    get_links_count() {
        const ret = wasm.urdfmodel_get_links_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.urdfmodel_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} name
     */
    constructor(name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.urdfmodel_new(ptr0, len0);
        this.__wbg_ptr = ret >>> 0;
        URDFModelFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) URDFModel.prototype[Symbol.dispose] = URDFModel.prototype.free;

export class Vector3 {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Vector3.prototype);
        obj.__wbg_ptr = ptr;
        Vector3Finalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Vector3Finalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_vector3_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get x() {
        const ret = wasm.__wbg_get_quaternion_x(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get y() {
        const ret = wasm.__wbg_get_quaternion_y(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get z() {
        const ret = wasm.__wbg_get_quaternion_z(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} arg0
     */
    set x(arg0) {
        wasm.__wbg_set_quaternion_x(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set y(arg0) {
        wasm.__wbg_set_quaternion_y(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set z(arg0) {
        wasm.__wbg_set_quaternion_z(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     */
    constructor(x, y, z) {
        const ret = wasm.vector3_new(x, y, z);
        this.__wbg_ptr = ret >>> 0;
        Vector3Finalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) Vector3.prototype[Symbol.dispose] = Vector3.prototype.free;

/**
 * @param {URDFModel} model
 * @param {Float64Array} joint_values
 * @returns {Transform[]}
 */
export function compute_forward_kinematics(model, joint_values) {
    _assertClass(model, URDFModel);
    const ptr0 = passArrayF64ToWasm0(joint_values, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.compute_forward_kinematics(model.__wbg_ptr, ptr0, len0);
    var v2 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v2;
}

/**
 * @param {string} xml_content
 * @returns {URDFModel}
 */
export function parse_urdf_xml(xml_content) {
    const ptr0 = passStringToWasm0(xml_content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parse_urdf_xml(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return URDFModel.__wrap(ret[0]);
}

/**
 * @returns {string}
 */
export function test_parsing() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.test_parsing();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_throw_be289d5034ed271b: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_error_7534b8e9a36f1ab4: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_log_8af1c4f0d4ecd27b: function(arg0, arg1) {
            console.log(getStringFromWasm0(arg0, arg1));
        },
        __wbg_new_8a6f238a6ece86ea: function() {
            const ret = new Error();
            return ret;
        },
        __wbg_stack_0ed75d68575b0f3c: function(arg0, arg1) {
            const ret = arg1.stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_transform_new: function(arg0) {
            const ret = Transform.__wrap(arg0);
            return ret;
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./urdf_parser_wasm_bg.js": import0,
    };
}

const JointDataFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_jointdata_free(ptr >>> 0, 1));
const LinkDataFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_linkdata_free(ptr >>> 0, 1));
const QuaternionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_quaternion_free(ptr >>> 0, 1));
const TransformFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_transform_free(ptr >>> 0, 1));
const URDFModelFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_urdfmodel_free(ptr >>> 0, 1));
const Vector3Finalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_vector3_free(ptr >>> 0, 1));

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

let cachedFloat64ArrayMemory0 = null;
function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasm;
function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedFloat64ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('urdf_parser_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
